package com.example.tcpclient.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.tcpclient.gateway.OrderGateway;
import com.example.tcpclient.model.SPackage;

@RestController
public class OrderController {

    @Autowired
	private  OrderGateway orderGateway;

	
	  @GetMapping(path = "/placeOrder") 
	  public String placeOrder(@RequestBody SPackage order) {
		  System.out.println(order.toString());
	  return this.orderGateway.placeOrder(order.toString()); }
	 
}
