package com.example.tcpclient.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.integration.annotation.IntegrationComponentScan;
import org.springframework.integration.channel.DirectChannel;
import org.springframework.integration.config.EnableIntegration;
import org.springframework.integration.dsl.IntegrationFlow;
import org.springframework.integration.dsl.IntegrationFlows;
import org.springframework.integration.dsl.Transformers;
import org.springframework.integration.ip.dsl.Tcp;
import org.springframework.integration.ip.tcp.TcpOutboundGateway;
import org.springframework.integration.ip.tcp.connection.AbstractClientConnectionFactory;
import org.springframework.integration.ip.tcp.connection.TcpNetClientConnectionFactory;
import org.springframework.integration.ip.tcp.serializer.TcpCodecs;
import org.springframework.messaging.MessageChannel;

import com.example.tcpclient.props.TcpClientProps;

/**
 * Spring annotation based configuration
 */
@Configuration
@EnableIntegration
@IntegrationComponentScan
public class IntegrationConfig {
	Logger log = LoggerFactory.getLogger(IntegrationConfig.class);
	private final TcpClientProps props;

	public IntegrationConfig(TcpClientProps props) {
		this.props = props;
	}

	@Bean
	public MessageChannel toTcp() {
		return new DirectChannel();
	}

	@Bean
	public IntegrationFlow integrationFlow() {
		log.debug("inside cloent !.....IntegrationFlow");
		return f -> f
				.handle(Tcp.outboundGateway(
						Tcp.nioClient(this.props.getHost(), this.props.getPort()).serializer(TcpCodecs.crlf()).get()))
				.transform(Transformers.objectToString());
	}

}
