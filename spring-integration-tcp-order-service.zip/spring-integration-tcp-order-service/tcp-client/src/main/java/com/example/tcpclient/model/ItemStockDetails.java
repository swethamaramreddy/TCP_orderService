package com.example.tcpclient.model;

import java.io.Serializable;

public class ItemStockDetails implements Serializable {
	private String itemName;
	private String stockDetails;
	
	public ItemStockDetails(String itemName, String stockDetails) {
		super();
		this.itemName = itemName;
		this.stockDetails = stockDetails;
	}
	public ItemStockDetails() {
		super();
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public String getStockDetails() {
		return stockDetails;
	}
	public void setStockDetails(String stockDetails) {
		this.stockDetails = stockDetails;
	}
	
	

}
