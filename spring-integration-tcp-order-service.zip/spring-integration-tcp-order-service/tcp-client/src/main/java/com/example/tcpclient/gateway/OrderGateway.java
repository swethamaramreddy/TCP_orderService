package com.example.tcpclient.gateway;

import java.util.concurrent.CompletableFuture;

import org.springframework.integration.annotation.Gateway;
import org.springframework.integration.annotation.MessagingGateway;

//@MessagingGateway(name = "Multitone", defaultRequestChannel = "integrationFlow.input")

@MessagingGateway(name = "Multitone", defaultRequestChannel = "integrationFlow.input")
public interface OrderGateway {

	/*
	 * @Gateway String hello(String payload);
	 */

    @Gateway
    CompletableFuture<String> placeAsync(String payload);
    
	
	  @Gateway 
	  String placeOrder(String order);
	 
}
