package com.example.tcpclient.model;

import java.io.Serializable;
import java.util.List;

import org.springframework.boot.configurationprocessor.json.JSONArray;

public class SPackage implements Serializable {
	
	private Integer messageType;
	private Integer payloadLength;
	private List<ItemStockDetails> itemStockList;
	public SPackage() {
		super();
	}
	public SPackage(Integer messageType, Integer payloadLength, List<ItemStockDetails> itemStockList) {
		super();
		this.messageType = messageType;
		this.payloadLength = payloadLength;
		this.itemStockList = itemStockList;
	}
	
	public Integer getMessageType() {
		return messageType;
	}
	
	public void setMessageType(Integer messageType) {
		this.messageType = messageType;
	}
	public Integer getPayloadLength() {
		return payloadLength;
	}
	public void setPayloadLength(Integer payloadLength) {
		this.payloadLength = payloadLength;
	}
	public List<ItemStockDetails> getItemStockList() {
		return itemStockList;
	}
	public void setItemStockList(List<ItemStockDetails> itemStockList) {
		this.itemStockList = itemStockList;
	}
	
	@Override
	public String toString() {
		
		return "{ \"messageType\": "+messageType+", \"payloadLength\": "+payloadLength+" , \"itemStockList\": "+itemStockList+"}";
	}

}
