package com.example.tcpserver.message;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.integration.transformer.GenericTransformer;
import org.springframework.stereotype.Component;

import com.example.tcpserver.model.ItemStockDetails;
import com.example.tcpserver.model.SPackage;
import com.example.tcpserver.util.OrderSerializerDeserializer;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class MessageTransformer implements GenericTransformer<String, String> {
	Logger logger = LoggerFactory.getLogger(MessageTransformer.class);

	@Override
	public String transform(String input) {
		logger.debug("inside MessageTransformer method !........" + input);

		SPackage orderPack = null;
		
		OrderSerializerDeserializer orderSerializerDeserializer = new OrderSerializerDeserializer();
		try {

			orderPack = new ObjectMapper().readValue(input, SPackage.class);
			orderPack= orderSerializerDeserializer.deserialize(orderPack);

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// System.out.println("Stock list from json file" + stockList.size());
		System.out.println(orderPack.getItemStockList());
		return String.valueOf(orderPack);
	}

}
