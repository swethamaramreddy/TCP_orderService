package com.example.tcpserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication

public class TcpServerApplication {

    public static void main(String[] args) {
    	System.out.println("inside server class ");
        SpringApplication.run(TcpServerApplication.class, args);
    }

}
