package com.example.tcpserver.util;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.example.tcpserver.model.ItemStockDetails;
import com.example.tcpserver.model.SPackage;
import com.fasterxml.jackson.databind.ObjectMapper;

public class OrderSerializerDeserializer {
	Logger logger = LoggerFactory.getLogger(OrderSerializerDeserializer.class);

	public SPackage deserialize(SPackage order) throws IOException {

		SPackage orderPack = order;
		JSONParser parser = new JSONParser();
		JSONObject jsonObject = null;
		List<ItemStockDetails> stockList = new ArrayList<ItemStockDetails>();
		if (orderPack.getMessageType() == 1) {

			try {
				InputStream inputStream = getClass().getClassLoader().getResourceAsStream("items.json");

				byte[] bytes = new byte[orderPack.getPayloadLength()];

				inputStream.read(bytes);

				String payLoadMessage = new String(bytes);

				jsonObject = (JSONObject) parser.parse(payLoadMessage.trim());

				JSONArray arr = (JSONArray) jsonObject.get("ItemStockDetails");

				Iterator iterator = arr.iterator();
				while (iterator.hasNext()) {

					ItemStockDetails items = new ObjectMapper().readValue(iterator.next().toString(),
							ItemStockDetails.class);

					stockList.add(items);

				}

				orderPack.setItemsStock(stockList);
			}

			catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		return orderPack;
	}

}
