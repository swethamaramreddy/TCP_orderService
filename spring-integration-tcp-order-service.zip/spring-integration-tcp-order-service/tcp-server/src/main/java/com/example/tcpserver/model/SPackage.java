package com.example.tcpserver.model;

import java.io.Serializable;
import java.util.List;



public class SPackage implements Serializable{
	private Integer messageType;
	private Integer payloadLength;
	private List<ItemStockDetails> itemStockList;
	
	public List<ItemStockDetails> getItemStockList() {
		return itemStockList;
	}
	public void setItemsStock(List<ItemStockDetails> itemStockList) {
		this.itemStockList = itemStockList;
	}

	public SPackage() {
		super();
	}
	public SPackage(Integer messageType, Integer payloadLength) {
		super();
		this.messageType = messageType;
		this.payloadLength = payloadLength;

	}
	public SPackage(Integer messageType, Integer payloadLength, List<ItemStockDetails> itemStockList) {
		super();
		this.messageType = messageType;
		this.payloadLength = payloadLength;
		this.itemStockList = itemStockList;
	}
	
	public Integer getMessageType() {
		return messageType;
	}
	
	public void setMessageType(Integer messageType) {
		this.messageType = messageType;
	}
	public Integer getPayloadLength() {
		return payloadLength;
	}
	public void setPayloadLength(Integer payloadLength) {
		this.payloadLength = payloadLength;
	}
	public String listToString()
	{
		return itemStockList.toString();
	}
	@Override
	public String toString() {
		return "{ \"messageType\": "+messageType+", \"payloadLength\": "+payloadLength+" , \"itemStockList\": "+itemStockList+"}";
	}
	

}
