package com.example.tcpserver.model;

import java.io.Serializable;

public class Order implements Serializable{
	private int orderId;
	private String items;
	private double price;
	public int getOrderId() {
		return orderId;
	}
	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
	public String getItems() {
		return items;
	}
	public void setItems(String items) {
		this.items = items;
	}
	public double getPrice() {
		return price;
	}
	public Order(int orderId, String items, double price) {
		super();
		this.orderId = orderId;
		this.items = items;
		this.price = price;
	}
	public void setPrice(double price) {
		this.price = price;
	}

}
